export enum CompressedExtensions {
  zip = "zip",
  tar = "tar"
}